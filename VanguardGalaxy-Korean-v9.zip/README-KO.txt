﻿Vanguard Galaxy 한국어 패치 v9 (Windows 64비트)

1. 게임을 완전히 종료하세요.
2. ZIP의 전체 내용물을 VanguardGalaxy.exe가 있는 폴더에 풀어주세요.
3. 기존 파일이 있다는 메시지가 뜨면 교체를 선택하고 게임을 다시 실행하세요.

이미 시작한 게임은 기존 세이브에서 이어서 플레이할 수 있습니다.
임무 본문, 목표의 수량과 위치, 정거장 메뉴, NPC 대화와 함선 툴팁을 보완했습니다.
제작소의 재료·결과물, 임무 목표와 스토리 대사에서 제작품 이름을 통일했습니다.
바에서 손님이 제안하는 거래와 의뢰 대사, 수량, 장비 레벨·등급 조건을 보완했습니다.
9개 기술 트리의 기술명과 효과 설명, 포인트 투자·회수 안내를 다듬었습니다.
이미 저장된 임무의 번역은 해당 화면에 표시될 때 교정합니다.
함선 형식과 모델 번호는 게임 내 식별 번호를 사용합니다.

한국어 표시에 Windows 맑은 고딕을 사용합니다. 사전에 있는 문구를 기기에서 번역합니다.
다른 BepInEx 모드를 함께 사용한다면 기존 BepInEx 폴더와 로더 설정을 먼저 백업하세요.
새 게임을 시작할 때 로딩이 계속 멈추면 게임 폴더의 BepInEx/LogOutput.log와
%USERPROFILE%\AppData\LocalLow\Bat Roost Games\VanguardGalaxy\Player.log를 확인하세요.

BepInEx 5.4.23.3, XUnity.AutoTranslator 5.6.3.1
https://github.com/BepInEx/BepInEx/releases/tag/v5.4.23.3
https://github.com/bbepis/XUnity.AutoTranslator/releases/tag/v5.6.3.1
